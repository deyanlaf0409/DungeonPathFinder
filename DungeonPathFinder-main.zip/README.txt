

g++ -o game game.cpp -lGL -lGLU -lglut -Wall

g++ game.cpp -o game -lopengl32 -lglu32 -lfreeglut




