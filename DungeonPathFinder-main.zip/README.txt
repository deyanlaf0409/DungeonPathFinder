
g++ game.cpp -o run -lopengl32 -lglu32 -lfreeglut -lglew32 -static -static-libgcc -static-libstdc++ -Wall






